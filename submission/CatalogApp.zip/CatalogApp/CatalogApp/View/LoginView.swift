//
//  LoginView.swift
//  CatalogApp
//
//  Created by septe habudin on 10/10/22.
//

import SwiftUI

struct LoginView: View {
    @Binding var username: String

    var body: some View {
        ZStack {
            SwiftUI.Color("ColorGray").ignoresSafeArea()
            ProgressView()
                .progressViewStyle(CircularProgressViewStyle(tint: Color.white))
                .onAppear(perform: login)
        }
    }

    func login() {
        Task {
            do {
                let user = try await realmApp.login(credentials: .anonymous)
                username = user.id
            } catch {
//                username = "123"
                print("Failed to log in \(error)")
            }
        }
    }
}

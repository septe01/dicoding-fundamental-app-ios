//
//  DetailView.swift
//  CatalogApp
//
//  Created by septe habudin on 03/10/22.
//

import SwiftUI
import RealmSwift

struct DetailView: View {
    @ObservedResults(FavoriteRealmModel.self, sortDescriptor: SortDescriptor(keyPath: "timeStamp", ascending: true)) var favorite
    @ObservedObject var vmDetail: DetailViewModel = DetailViewModel()
    @State var isLike: Bool = false

    var username: String = ""
    var id: String = ""
    var screenShoot: [ShortScreenshot] = []
    var scr: String = ""

    var body: some View {
        ZStack {
            SwiftUI.Color("ColorGray").ignoresSafeArea()
            ZStack {
                SwiftUI.Color("ColorBlack")
                if vmDetail.isLoading{
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: Color.white))
                }else {
                    ScrollView {
                        VStack {
                            CardListView(screenShoot: screenShoot)
                                .frame(height: 400)

                            if let detail = vmDetail.detailGames {

                                HStack {
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text(detail.name!)
                                            .font(.headline)
                                            .bold()
                                            .foregroundColor(.white)

                                        SubHeader(platform: detail.parentPlatforms, rating: detail.rating!, scr: "detail")
                                        HStack {
                                            Text("Release")
                                                .font(.caption2)
                                                .foregroundColor(.white)
                                            Divider()
                                                .overlay(.gray)
                                            Text(detail.released!)
                                                .font(.caption2)
                                                .foregroundColor(.white)
                                        }
                                    }
                                    if scr != "favorite" {
                                        Spacer()
                                        Image(systemName: isLike ? "suit.heart.fill" : "heart")
                                            .foregroundColor(.white)
                                            .font(.system(size: 16))
                                            .onTapGesture {
                                                isLike.toggle()
                                                handleOnLike()
                                            }
                                    }

                                }
                                .padding()

                                Divider()
                                    .frame(height: 1)
                                    .overlay(.gray)

                                Text(detail.descriptionRaw!)
                                    .font(.subheadline)
                                    .bold()
                                    .foregroundColor(.white)
                                    .padding()
                            }
                            Spacer()
                        }
                    }
                }
            }
            .accentColor(.white)
        }
        .onAppear(perform: {
            vmDetail.getData(id: id)
            vmDetail.getFavoriteBy(user: username, gamesId: id)
            isLike = vmDetail.isFavorite
        })
        .accentColor(.white)
        .navigationTitle(Text("Detail"))
        .navigationBarTitleDisplayMode(.inline)
    }

    private func handleOnLike() {
        if isLike {
            vmDetail.addFavorite(user: username, gamesId: id, isLike: isLike)
        } else {
            vmDetail.deletFavorite(user: username, gamesId: id)
        }
    }

}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView()
    }
}

//
//  CardListView.swift
//  CatalogApp
//
//  Created by septe habudin on 03/10/22.
//

import SwiftUI

struct CardListView: View {

    var screenShoot: [ShortScreenshot] = []

    var body: some View {
        TabView {
            ForEach(screenShoot, id: \.id) { media in
                AsyncImage(url: URL(string: media.image!)) { image in
                    image
                        .resizable()
                } placeholder: {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: Color.white))
                }
            }
        }
        .tabViewStyle(.page)
    }

}

struct CardListView_Previews: PreviewProvider {
    static var previews: some View {
        CardListView()
    }
}

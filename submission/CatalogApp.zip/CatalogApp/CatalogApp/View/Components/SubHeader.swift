//
//  SubHeader.swift
//  CatalogApp
//
//  Created by septe habudin on 09/10/22.
//

import SwiftUI

struct SubHeader: View {
    var platform: [ParentPlatform] = []
    var rating: Double = 0.0
    var scr: String = ""

    var body: some View {
        HStack(spacing: 2) {
            ForEach(platform, id: \.platform.id) { platform in
                PlatForm(platform: (platform.platform.name!))
            }
            if scr == "home" {
                Spacer()
            }
            Image(systemName: "star.fill")
                .foregroundColor(.yellow)
                .font(.system(size: 10))
            Text("\(String(format: "%.1f", rating))")
                .font(.caption)
                .bold()
                .foregroundColor(.white)

            if scr != "home" {
                Spacer()
            }
        }
    }
}

struct PlatForm: View {
    var platform: String
    var body: some View {
        HStack {
            if platform == "PC" || platform == "PlayStation" || platform == "Xbox" || platform == "Nintendo" {
                Image(systemName: platform == "PC" ? "laptopcomputer" : platform == "PlayStation" ? "logo.playstation" : platform == "Xbox" ? "logo.xbox" : "n.square")
                    .foregroundColor(.white)
                    .font(.system(size: 10))
            }
        }
    }
}

struct SubHeader_Previews: PreviewProvider {
    static var previews: some View {
        SubHeader()
    }
}

//
//  NavTabView.swift
//  CatalogApp
//
//  Created by septe habudin on 03/10/22.
//

import SwiftUI

struct NavTabView: View {

    @State private var username = ""
    @State var selection = 1

    init() {
        if #available(iOS 15, *) {
            let navigationBarAppearance = UINavigationBarAppearance()
            navigationBarAppearance.configureWithOpaqueBackground()
            navigationBarAppearance.titleTextAttributes = [
                NSAttributedString.Key.foregroundColor: UIColor.white
            ]
            navigationBarAppearance.largeTitleTextAttributes = [
                NSAttributedString.Key.foregroundColor: UIColor.white
            ]
            navigationBarAppearance.backgroundColor = UIColor(named: "ColorGray")
            UINavigationBar.appearance().standardAppearance = navigationBarAppearance
            UINavigationBar.appearance().compactAppearance = navigationBarAppearance
            UINavigationBar.appearance().scrollEdgeAppearance = navigationBarAppearance

            let backItemAppearance = UIBarButtonItemAppearance()
            backItemAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.white]
            navigationBarAppearance.backButtonAppearance = backItemAppearance

            let image = UIImage(systemName: "chevron.backward")?.withTintColor(.white, renderingMode: .alwaysOriginal)
            navigationBarAppearance.setBackIndicatorImage(image, transitionMaskImage: image)

            let tabBarApperance = UITabBarAppearance()
            tabBarApperance.configureWithOpaqueBackground()
            tabBarApperance.backgroundColor = UIColor(named: "ColorGray")
            UITabBar.appearance().scrollEdgeAppearance = tabBarApperance
            UITabBar.appearance().standardAppearance = tabBarApperance
        }
    }

    var body: some View {
        
        NavigationView {
            if username == "" {
                LoginView(username: $username)
            } else {
                TabView(selection: $selection) {
                    HomeView(username: username)
                        .tabItem {
                            Label("Games", systemImage: "gamecontroller.fill")
                        }
                        .tag(1)

                    FavoriteView(username: username)
                        .tabItem {
                            Label("Favorite", systemImage: "heart.fill")
                        }
                        .tag(2)

                    AboutView()
                        .tabItem {
                            Label("About", systemImage: "person.crop.circle.fill")
                        }
                        .tag(3)
                }
                .accentColor(.white)
                .navigationTitle(selection == 1 ? "Games" : selection == 2 ? "Favorite" : "About")
                .navigationBarTitleDisplayMode(.inline)
            }
        }

    }
    
}

struct NavTabView_Previews: PreviewProvider {
    static var previews: some View {
        NavTabView()
    }
}

//
//  HomeView.swift
//  CatalogApp
//
//  Created by septe habudin on 03/10/22.
//

import SwiftUI

struct HomeView: View {
    
    @ObservedObject private var vmHome: HomeViewModel = HomeViewModel()
    var username: String = ""
    
    private let adaptiveColums = [
        GridItem(.adaptive(minimum: 150, maximum: 170), spacing: 10, alignment: .top)
    ]
    
    var body: some View {
        ZStack {
            SwiftUI.Color("ColorGray").ignoresSafeArea()
            ZStack {
                SwiftUI.Color("ColorBlack")
                if vmHome.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: Color.white))
                }else {
                    ScrollView {
                        LazyVGrid(columns: adaptiveColums, spacing: 10) {
                            if let dataGames = vmHome.games {
                                ForEach(dataGames.results) { item in
                                    NavigationLink(destination: DetailView(username: username, id: "\(item.id!)", screenShoot: item.shortScreenshots), label: {
                                        VStack(alignment: .leading) {
                                            AsyncImage(url: URL(string: item.backgroundImage!)) { Image in
                                                Image
                                                    .resizable()
                                                    .frame(width: 170, height: 140)
                                            } placeholder: {
                                                ZStack {
                                                    ProgressView()
                                                        .progressViewStyle(CircularProgressViewStyle(tint: Color.white))
                                                }.frame(width: 170, height: 140
                                                )
                                                
                                            }
                                            VStack(alignment: .leading, spacing: 10) {
                                                SubHeader(platform: item.parentPlatforms, rating: item.rating!, scr: "home")
                                                
                                                Text(item.name!)
                                                    .font(.subheadline)
                                                    .bold()
                                                    .foregroundColor(.white)

                                                Text(item.released!)
                                                    .font(.caption2)
                                                    .foregroundColor(.white)
                                            }
                                            .padding(.all, 8)
                                            
                                        }
                                        .background(SwiftUI.Color("ColorGray"))
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                        .shadow(radius: 8)
                                    })
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
        }
    }
    
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

//
//  NetWorkManager.swift
//  CatalogApp
//
//  Created by septe habudin on 12/10/22.
//

import Foundation
import Network

class NetWorkManager: ObservableObject {
    let monitor: NWPathMonitor = NWPathMonitor()
    let queue = DispatchQueue(label: "NetworkManager")
    @Published var isConnected: Bool = true

    init() {
        monitor.pathUpdateHandler = { path in
            DispatchQueue.main.async {
                    self.isConnected = path.status == .satisfied
            }
        }

        monitor.start(queue: queue)
    }

}

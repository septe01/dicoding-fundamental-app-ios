//
//  Utils.swift
//  CatalogApp
//
//  Created by septe habudin on 09/10/22.
//

import Foundation

//
//  FavoriteViewModel.swift
//  CatalogApp
//
//  Created by septe habudin on 11/10/22.
//

import Foundation
import Alamofire
import SwiftyJSON
import RealmSwift

class FavoriteViewModel: ObservableObject {
    @ObservedResults(FavoriteRealmModel.self, sortDescriptor: SortDescriptor(keyPath: "timeStamp", ascending: true)) var favorite
    @Published var results: [Result] = []
    @Published var isLoading: Bool = true
    
    init() {
        getData()
    }

    func getData() {
        let url = "https://api.rawg.io/api/games?key=a6a956cc10bf45f883d50b3e6298648c"

        AF.request(url, method: .get).responseDecodable(of: GamesModel.self) { response in
            switch response.result {
            case .success:
                let response = try? JSONDecoder().decode(GamesModel.self, from: response.data!)

                if !self.favorite.isEmpty{
                    for favorite in self.favorite {
                        if let i = response?.results.firstIndex(where: { $0.id == Int(favorite.gamesId) }) {
                            self.results.append((response?.results[i])!)
                        }
                    }
                    self.isLoading = false
                }
            case .failure:
                print("response erorr -> \(response.error!)")
            }
        }
    }
}

//
//  DetailViewModel.swift
//  CatalogApp
//
//  Created by septe habudin on 09/10/22.
//

import Foundation
import Alamofire
import SwiftyJSON
import RealmSwift

class DetailViewModel: ObservableObject {
    @ObservedResults(FavoriteRealmModel.self, sortDescriptor: SortDescriptor(keyPath: "timeStamp", ascending: true)) var favorite
    @Published var detailGames: DetailModel?
    @Published var isFavorite: Bool = false
    @Published var isLoading: Bool = true
    @Published var games: GamesModel?

    init(detailGames: DetailModel? = nil) {
        self.detailGames = detailGames
    }

    func getData(id: String) {
        let url = "https://api.rawg.io/api/games/\(id)?key=a6a956cc10bf45f883d50b3e6298648c"

        AF.request(url, method: .get).responseData {response in
            switch response.result {
            case .success:
                let result = try? JSONDecoder().decode(DetailModel.self, from: response.data!)
                self.detailGames = result
                self.isLoading = false

            case .failure:
                print("response erorr -> \(response.error!)")
            }
        }
    }

    func addFavorite(user: String, gamesId: String, isLike: Bool) {
        let newFavorite = FavoriteRealmModel(user: user, gamesId: gamesId, isFavorite: isLike)
        $favorite.append(newFavorite)
    }

    func getFavoriteBy(user: String, gamesId: String) {
        let realm = try! Realm()
        if realm.objects(FavoriteRealmModel.self).filter("gamesId = %@ AND user = %@ ", gamesId, user).first != nil {
            isFavorite = true
        }
    }

    func deletFavorite(user: String, gamesId: String) {
        let realm = try! Realm()
        let object = realm.objects(FavoriteRealmModel.self).filter("gamesId = %@ AND user = %@ ", gamesId, user).first
        try! realm.write {
            if let obj = object {
                realm.delete(obj)
            }
        }

    }
}

//
//  HomeViewModel.swift
//  CatalogApp
//
//  Created by septe habudin on 05/10/22.
//

import Foundation
import Alamofire
import SwiftyJSON

class HomeViewModel: ObservableObject {

    @Published var games: GamesModel?
    @Published var isLoading: Bool = true

    init() {
        getData()
    }

    func getData() {
        let url = "https://api.rawg.io/api/games?key=a6a956cc10bf45f883d50b3e6298648c"

        AF.request(url, method: .get).responseDecodable(of: GamesModel.self) { response in
            switch response.result {
            case .success:
                let response = try? JSONDecoder().decode(GamesModel.self, from: response.data!)
                self.games = response
                self.isLoading = false

            case .failure:
                print("response erorr -> \(response.error!)")
            }
        }
    }
}

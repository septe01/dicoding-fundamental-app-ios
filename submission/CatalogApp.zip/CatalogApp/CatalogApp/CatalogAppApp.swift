//
//  CatalogAppApp.swift
//  CatalogApp
//
//  Created by septe habudin on 03/10/22.
//

import SwiftUI
import RealmSwift
import SwiftUISnackbar

// connect to service mongo
let realmApp = RealmSwift.App(id: "favoritegames-gqlsk")

@main
struct CatalogAppApp: SwiftUI.App {
    @ObservedObject var networkManager = NetWorkManager()

    @State var show: Bool = true
    @State var notShow: Bool = false
    var body: some Scene {
        WindowGroup {
            NavTabView()
                .snackbar(isShowing: !networkManager.isConnected ? $show : $notShow, title: "No Connection", text: "Turn on your data network", style: .custom(.red))

        }
    }
}

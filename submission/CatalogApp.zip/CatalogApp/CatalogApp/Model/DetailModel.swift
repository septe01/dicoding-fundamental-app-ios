//
//  DetailModel.swift
//  CatalogApp
//
//  Created by septe habudin on 10/10/22.
//
import Foundation

// MARK: - DetailModel
struct DetailModel: Codable {
    let id: Int?
    let slug, name, detailModelDescription, released: String?
    let updated: String?
    let backgroundImage, backgroundImageAdditional: String?
    let website: String?
    let rating: Double?
    let ratingTop, playtime, screenshotsCount, reviewsTextCount: Int?
    let ratingsCount, reviewsCount: Int?
    let parentPlatforms: [ParentPlatform]
    let developers, genres, tags: [Developer]
    let esrbRating: EsrbRating
    let descriptionRaw: String?

    enum CodingKeys: String, CodingKey {
        case id, slug, name
        case detailModelDescription = "description"
        case released, updated
        case backgroundImage = "background_image"
        case backgroundImageAdditional = "background_image_additional"
        case website, rating
        case ratingTop = "rating_top"
        case playtime
        case screenshotsCount = "screenshots_count"
        case reviewsTextCount = "reviews_text_count"
        case ratingsCount = "ratings_count"
        case reviewsCount = "reviews_count"
        case parentPlatforms = "parent_platforms"
        case developers, genres, tags
        case esrbRating = "esrb_rating"
        case descriptionRaw = "description_raw"
    }
}

// MARK: - Developer
struct Developer: Codable {
    let id: Int?
    let name, slug: String?
    let gamesCount: Int?
    let imageBackground: String?
    let language: String?

    enum CodingKeys: String, CodingKey {
        case id, name, slug
        case gamesCount = "games_count"
        case imageBackground = "image_background"
        case language
    }
}

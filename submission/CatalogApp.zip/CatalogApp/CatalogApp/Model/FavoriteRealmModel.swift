//
//  FavoriteRealmModel.swift
//  CatalogApp
//
//  Created by septe habudin on 10/10/22.
//

import Foundation
import RealmSwift

class FavoriteRealmModel: Object, ObjectKeyIdentifiable {
    @Persisted(primaryKey: true) var _id: ObjectId
    @Persisted var user: String
    @Persisted var gamesId: String
    @Persisted var isFavorite: Bool
    @Persisted var timeStamp = Date()

    convenience init(user: String, gamesId: String, isFavorite: Bool) {
        self.init()

        self.user = user
        self.gamesId = gamesId
        self.isFavorite = isFavorite
    }
}

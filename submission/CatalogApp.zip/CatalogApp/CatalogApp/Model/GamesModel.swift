//
//  GamesModel.swift
//  CatalogApp
//
//  Created by septe habudin on 03/10/22.
//

import Foundation

// MARK: - GamesModel
struct GamesModel: Codable {
    let count: Int?
    let next: String?
    let previous: String?
    let results: [Result]
}

// MARK: - Result
struct Result: Codable, Identifiable {
    let id: Int?
    let slug, name, released: String?
    let backgroundImage: String?
    let rating: Double?
    let ratingTop: Int?
    let ratings: [Rating]
    let ratingsCount, reviewsTextCount, added, metacritic: Int?
    let playtime, suggestionsCount: Int?
    let updated: String?
    let reviewsCount: Int?
    let parentPlatforms: [ParentPlatform]
    let genres, tags: [Genre]
    let esrbRating: EsrbRating
    let shortScreenshots: [ShortScreenshot]

    enum CodingKeys: String, CodingKey {
        case id, slug, name, released
        case backgroundImage = "background_image"
        case rating
        case ratingTop = "rating_top"
        case ratings
        case ratingsCount = "ratings_count"
        case reviewsTextCount = "reviews_text_count"
        case added, metacritic, playtime
        case suggestionsCount = "suggestions_count"
        case updated
        case reviewsCount = "reviews_count"
        case parentPlatforms = "parent_platforms"
        case genres, tags
        case esrbRating = "esrb_rating"
        case shortScreenshots = "short_screenshots"
    }
}

// MARK: - EsrbRating
struct EsrbRating: Codable {
    let id: Int?
    let name, slug: String?
}

// MARK: - Genre
struct Genre: Codable {
    let id: Int?
    let name, slug: String?
    let gamesCount: Int?
    let imageBackground: String?
    let language: String?

    enum CodingKeys: String, CodingKey {
        case id, name, slug
        case gamesCount = "games_count"
        case imageBackground = "image_background"
        case language
    }
}

// MARK: - ParentPlatform
struct ParentPlatform: Codable {
    let platform: EsrbRating
}

// MARK: - Rating
struct Rating: Codable {
    let id: Int?
    let title: String?
    let count: Int?
    let percent: Double?
}

// MARK: - ShortScreenshot
struct ShortScreenshot: Codable {
    let id: Int?
    let image: String?
}

extension GamesModel {
    static var mockDataGames =
    GamesModel(
        count: 805960,
        next: "https://api.rawg.io/api/games?key=a6a956cc10bf45f883d50b3e6298648c&page=2&page_size=1",
        previous: nil,
        results: [
            Result(
                id: 3498,
                slug: "grand-theft-auto-v",
                name: "Grand Theft Auto V",
                released: "2013-09-17",
                backgroundImage: "https://media.rawg.io/media/games/456/456dea5e1c7e3cd07060c14e96612001.jpg",
                rating: 4.47,
                ratingTop: 5,
                ratings: [
                    Rating(
                        id: 5,
                        title: "Title",
                        count: 3535,
                        percent: 59.7)
                ],
                ratingsCount: 5917,
                reviewsTextCount: 43,
                added: 18069,
                metacritic: 91,
                playtime: 71,
                suggestionsCount: 407,
                updated: "2022-10-04T11:41:50",
                reviewsCount: 5992,
                parentPlatforms: [ParentPlatform(platform: EsrbRating(id: 2, name: "PlayStation", slug: "playStation"))],
                genres: [Genre(id: 1, name: "Action", slug: "action", gamesCount: 16267, imageBackground: "https://media.rawg.io/media/games/b7b/b7b8381707152afc7d91f5d95de70e39.jpg", language: "eng")],
                tags: [Genre(id: 3, name: "SinglePlayer", slug: "singleplayer", gamesCount: 12314, imageBackground: "https://media.rawg.io/media/games/73e/73eecb8909e0c39fb246f457b5d6cbbe.jpg", language: "eng")],
                esrbRating: EsrbRating(id: 4, name: "Mature", slug: "mature"),
                shortScreenshots: [ShortScreenshot(id: 1, image: "https://media.rawg.io/media/games/456/456dea5e1c7e3cd07060c14e96612001.jpg")])
        ]
    )
}
